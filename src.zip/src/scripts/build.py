#!/usr/bin/env python3
"""Build dependency-free HTML pages from one layout and shared project data."""
import json
import os
import re
import urllib.error
import urllib.request
from html import escape
from pathlib import Path
from string import Template
from urllib.parse import quote, urlparse

_SCRIPT_DIR = Path(__file__).resolve().parent
ROOT = _SCRIPT_DIR.parents[1] if _SCRIPT_DIR.parent.name == 'src' else _SCRIPT_DIR.parent
SOURCE = ROOT / 'src'
SITE = json.loads((SOURCE / 'data/site.json').read_text())
PROJECTS = json.loads((SOURCE / 'data/projects.json').read_text())
LAYOUT = Template((SOURCE / 'templates/layout.html').read_text())
I18N = json.loads((SOURCE / 'data/i18n.json').read_text())
SUPPORT_FEED = SITE.get('support_feed', '').strip()
SUPPORT_OVERRIDES_PATH = SOURCE / 'data/support-overrides.json'
ORIGIN = SITE['origin'].rstrip('/')
PHONE = SITE.get('phone', '').strip()
PUBLIC = '/src'
ASSETS = PUBLIC + '/assets'
LOGO = ASSETS + '/images/logo.png'


def phone_href():
    return 'tel:' + re.sub(r'[^\d+]', '', PHONE)


def phone_display():
    digits = re.sub(r'\D', '', PHONE)
    if digits.startswith('49') and digits[2:5] == '163':
        return f'+49 163 {digits[5:]}'
    return PHONE


def locale_root(lang):
    return PUBLIC if lang == 'en' else PUBLIC + '/de'


def locale_home(lang):
    return '/' if lang == 'en' else PUBLIC + '/de/'


def localized_url(path, lang):
    if path == '/':
        return '/' if lang == 'en' else PUBLIC + '/de/'
    if path == '/error-page.html':
        return '/error-page.html' if lang == 'en' else PUBLIC + '/de/error-page.html'
    prefix = PUBLIC if lang == 'en' else PUBLIC + '/de'
    return prefix + path


def output_file(localized):
    if localized == '/':
        return 'index.html'
    rel = localized.lstrip('/')
    if rel.endswith('.html'):
        return rel
    if not rel.endswith('/'):
        rel += '/'
    return rel + 'index.html'


def page_source(name, lang):
    if lang == 'de':
        german = SOURCE / f'pages/de/{name}.html'
        if german.exists():
            return german
    return SOURCE / f'pages/{name}.html'


def text_for(project, lang, field):
    if lang == 'de' and project.get(field + '_de'):
        return project[field + '_de']
    return project[field]


def write(path, content):
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding='utf-8')


def local_projects():
    return [p for p in PROJECTS if not p.get('url')]


def project_href(project, root):
    url = project.get('url')
    if url:
        return escape(url, quote=True)
    return f"{root}/projects/{escape(project['slug'])}/"


def icon(project, extra=''):
    if project['icon']:
        return f'<img class="app-icon {extra}" src="{escape(project["icon"])}" alt="" width="80" height="80">'
    return '<span class="app-icon monogram-icon" aria-hidden="true">2FA</span>'


def project_cards(lang, root, copy, projects=None):
    cards = []
    for p in projects if projects is not None else local_projects():
        cards.append(f'''<a class="project-card" href="{project_href(p, root)}">
          <div class="project-info"><p class="project-status">{escape(text_for(p, lang, 'status'))}</p><h3>{escape(p['name'])}</h3>
          <p>{escape(text_for(p, lang, 'description'))}</p><span class="text-link">{escape(copy['learn_more'])} <span aria-hidden="true">›</span></span></div>
          <div class="project-art project-art--{escape(p['slug'])}">{icon(p)}</div></a>''')
    return '\n'.join(cards)


def latest_cards(lang, root, copy):
    return project_cards(lang, root, copy, [p for p in PROJECTS if p.get('on_home')])


def project_tiles(root):
    tiles = []
    for p in PROJECTS:
        extra = ' rel="noopener"' if p.get('url') else ''
        tiles.append(
            f'<a class="project-tile" href="{project_href(p, root)}"{extra}>'
            f'{icon(p)}<h2>{escape(p["name"])}</h2></a>'
        )
    return '\n'.join(tiles)


def dollar(text):
    return text.replace('$', '$$')


def public_image(value):
    if not value or not isinstance(value, str):
        return ''
    parsed = urlparse(value.strip())
    if parsed.scheme in ('http', 'https') and parsed.netloc:
        return value.strip()
    return ''


def paragraphs(text):
    chunks = [chunk.strip() for chunk in (text or '').split('\n\n') if chunk.strip()]
    return ''.join(f'<p>{escape(chunk).replace(chr(10), "<br>")}</p>' for chunk in chunks)


def section_id(label, project):
    if project:
        return project['slug']
    slug = re.sub(r'[^a-z0-9]+', '-', label.casefold()).strip('-')
    taken = {item['slug'] for item in PROJECTS}
    if not slug or slug in taken:
        slug = ('topic-' + slug) if slug else 'general'
    return slug


def match_project(label):
    key = label.casefold()
    for project in PROJECTS:
        if project['name'].casefold() == key or project['slug'].casefold() == key:
            return project
    return None


def position_key(row):
    value = row.get('age')
    if value in (None, ''):
        return (1, 0)
    try:
        return (0, float(value))
    except (TypeError, ValueError):
        return (1, 0)


def fetch_support_rows(endpoint):
    rows, page = [], 1
    while page <= 20:
        separator = '&' if '?' in endpoint else '?'
        url = f'{endpoint}{separator}page={page}&limit=100'
        key = os.environ.get('APPBACKEND_API_KEY')
        if key:
            url += '&api_key=' + quote(key)
        request = urllib.request.Request(url, headers={
            'Accept': 'application/json',
            'User-Agent': 'sgroi.ga-build',
        })
        with urllib.request.urlopen(request, timeout=20) as response:
            payload = json.loads(response.read().decode())
        batch = payload.get('data') or []
        rows.extend(batch)
        total = int(payload.get('count') or 0)
        if not batch or len(rows) >= total:
            break
        page += 1
    return rows


def article_html(row):
    title = (row.get('name') or '').strip() or 'Untitled'
    body = paragraphs(row.get('content'))
    image = public_image(row.get('attachment'))
    figure = ''
    if image:
        figure = (
            f'<figure class="answer-screenshot"><img src="{escape(image, quote=True)}" '
            f'alt="{escape(title, quote=True)}" loading="lazy"></figure>'
        )
    return f'<details name="support-answers"><summary>{escape(title)}</summary><div>{body}{figure}</div></details>'


def support_cards(lang):
    cards = []
    for project in local_projects():
        slug = escape(project['slug'])
        cards.append(
            f'<a class="support-card" href="#{slug}" data-support-app="{slug}">'
            f'{icon(project)}'
            f'<h2>{escape(project["name"])}</h2>'
            f'<p>{escape(text_for(project, lang, "description"))}</p></a>'
        )
    return '\n'.join(cards)


def support_articles_html(articles, copy):
    grouped = {}
    for row in articles:
        raw = (row.get('application') or '').strip() or 'General'
        project = match_project(raw)
        label = project['name'] if project else raw
        grouped.setdefault(label, []).append(row)
    for rows in grouped.values():
        rows.sort(key=lambda row: (position_key(row), (row.get('name') or '').casefold()))

    sections = []
    seen = set()
    ordered = []
    for project in local_projects():
        ordered.append((project['name'], project))
        seen.add(project['name'].casefold())
        seen.add(project['slug'].casefold())
    for label in grouped:
        if label.casefold() not in seen:
            ordered.append((label, match_project(label)))

    if not ordered:
        return f'<p class="answers-empty">{escape(copy["answers_none"])}</p>'

    email = escape(SITE['email'])
    for label, project in ordered:
        rows = grouped.get(label, [])
        identifier = section_id(label, project)
        title_id = f'answers-title-{identifier}'
        heading = escape(project['name'] if project else label)
        if rows:
            items = ''.join(article_html(row) for row in rows)
        else:
            subject = quote(f'{project["name"] if project else label} Support')
            items = (
                f'<p class="answers-empty">{escape(copy["answers_empty"])} '
                f'<a href="mailto:{email}?subject={subject}">{escape(copy["answers_send"])}</a> '
                f'{escape(copy["answers_mention"])}</p>'
            )
        sections.append(
            f'<section class="answer-group" id="{escape(identifier)}" aria-labelledby="{title_id}">'
            f'<h2 id="{title_id}">{heading}</h2>{items}</section>'
        )
    return '\n'.join(sections)


def page(path, title, description, content, lang, image=None):
    copy = I18N[lang]
    root = locale_root(lang)
    home = locale_home(lang)
    localized = localized_url(path, lang)
    en_url = localized_url(path, 'en')
    de_url = localized_url(path, 'de')
    url = ORIGIN + localized
    store = SITE['app_store_url'] or (root + '/apps/')
    social = ''
    if image:
        image_url = escape(ORIGIN + image, quote=True)
        social = f'<meta property="og:image" content="{image_url}"><meta name="twitter:image" content="{image_url}"><meta property="og:image:alt" content="{escape(title)}">'
    output = LAYOUT.substitute(
        html_lang=lang,
        title=escape(title), description=escape(description), canonical=escape(url),
        hreflang_en=escape(ORIGIN + (en_url if en_url != '/' else '/')),
        hreflang_de=escape(ORIGIN + de_url),
        year=escape(SITE['year']),
        app_store_url=escape(store, quote=True),
        content=content, social_image=social, twitter_card='summary',
        projects_current='aria-current="page"' if path == '/projects/' else ('aria-current="true"' if path.startswith('/projects/') else ''),
        support_current='aria-current="page"' if path == '/Support/' else '',
        blog_url=escape(SITE.get('blog_url') or 'https://medium.com/@sgroiga', quote=True),
        home=home, root=root or '',
        assets=ASSETS,
        lang_en_href=en_url,
        lang_de_href=de_url,
        en_current='aria-current="true"' if lang == 'en' else '',
        de_current='aria-current="true"' if lang == 'de' else '',
        en_selected='selected' if lang == 'en' else '',
        de_selected='selected' if lang == 'de' else '',
        skip=escape(copy['skip']), home_label=escape(copy['home_label']),
        nav_about=escape(copy['nav_about']), nav_projects=escape(copy['nav_projects']),
        nav_support=escape(copy['nav_support']), nav_blog=escape(copy['nav_blog']),
        nav_main=escape(copy['nav_main']), nav_legal=escape(copy['nav_legal']),
        menu=escape(copy['menu']),
        lang_label=escape(copy['lang_label']), follow_me=escape(copy['follow_me']), social_label=escape(copy['social_label']),
        footer_tag=escape(copy['footer_tag']),
        footer_tag_url=escape(copy['footer_tag_url'], quote=True),
        back_top=escape(copy['back_top']),
        imprint=escape(copy['imprint']), privacy=escape(copy['privacy']), terms=escape(copy['terms']),
    )
    write(output_file(localized), output)


def redirect_document(target):
    escaped = escape(target, quote=True)
    if target.startswith(('http://', 'https://')):
        canonical = escaped
    else:
        canonical = escape(ORIGIN + target, quote=True)
    return f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="0; url={escaped}"><meta name="robots" content="noindex">
<link rel="canonical" href="{canonical}"><link rel="stylesheet" href="/src/assets/css/styles.css"><title>Page moved — Gabriel Sgroi</title></head>
<body><main class="page-intro wrap"><h1>This page has moved</h1><p><a class="text-link" href="{escaped}">Continue to the new page ›</a></p></main></body></html>\n'''


def redirects():
    """Keep old legal, support and app links working on Apache and Netlify."""
    mapping = {
        '/Impressum': '/src/legal/imprint/',
        '/Privacy': '/src/legal/privacy/',
        '/Terms': '/src/legal/terms/',
        '/legal/impressum': '/src/legal/imprint/',
        '/blog': SITE.get('blog_url') or 'https://medium.com/@sgroiga',
    }
    for project in local_projects():
        slug = project['slug']
        mapping[f'/soft/{slug}'] = f'/src/projects/{slug}/'
        mapping[f'/soft/privacy-{slug}'] = '/src/legal/privacy/'
        mapping[f'/soft/terms-{slug}'] = '/src/legal/terms/'
        mapping[f'/soft/support-{slug}'] = f'/src/Support/#{slug}'
    apache = ['# Generated by scripts/build.py. Permanent redirects for existing app and legal links.', '<IfModule mod_alias.c>']
    netlify = ['# Generated by scripts/build.py. Legacy app-page and legal redirects.']
    for old, target in mapping.items():
        apache.append(f'RedirectMatch 301 ^{re.escape(old)}(?:\\.html|/)?$ {target}')
        for suffix in ('', '.html', '/'):
            netlify.append(f'{old}{suffix} {target} 301')
    for old, new in (
        ('/projects', '/src/projects'),
        ('/Support', '/src/Support'),
        ('/legal', '/src/legal'),
        ('/apps', '/src/apps'),
        ('/de', '/src/de'),
        ('/assets', '/src/assets'),
    ):
        apache.append(f'RedirectMatch 301 ^{re.escape(old)}(/.*)?$ {new}$1')
        netlify.append(f'{old} {new}/ 301')
        netlify.append(f'{old}/* {new}/:splat 301')
    apache.append('</IfModule>')
    apache.append('ErrorDocument 404 /error-page.html')
    netlify.append('/* /error-page.html 404')
    write('.htaccess', '\n'.join(apache) + '\n')
    write('_redirects', '\n'.join(netlify) + '\n')


def load_support_overrides():
    if not SUPPORT_OVERRIDES_PATH.exists():
        return []
    try:
        rows = json.loads(SUPPORT_OVERRIDES_PATH.read_text())
    except (OSError, json.JSONDecodeError) as error:
        print('Warning: support overrides unreadable:', error)
        return []
    return rows if isinstance(rows, list) else []


def merge_support_articles(remote_rows, overrides):
    if not overrides:
        return remote_rows
    overridden = {
        str(row.get('application') or '').strip().casefold()
        for row in overrides
        if str(row.get('application') or '').strip()
    }
    merged = [
        row for row in remote_rows
        if str(row.get('application') or '').strip().casefold() not in overridden
    ]
    merged.extend(overrides)
    print(f'Applied {len(overrides)} local support override(s) for: {", ".join(sorted(overridden)) or "none"}')
    return merged


def load_support_articles():
    remote = []
    if not SUPPORT_FEED:
        print('Warning: no support_feed in site.json; support articles skipped.')
    else:
        try:
            remote = fetch_support_rows(SUPPORT_FEED)
            print(f'Loaded {len(remote)} support article(s) from AppBackend.')
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, ValueError) as error:
            print('Warning: support feed unavailable:', error)
    return merge_support_articles(remote, load_support_overrides())


def build():
    articles = load_support_articles()
    routes = [
        ('legal', '/legal/', 'legal_title', 'legal_desc'),
        ('imprint', '/legal/imprint/', 'imprint_title', 'imprint_desc'),
        ('privacy', '/legal/privacy/', 'privacy_title', 'privacy_desc'),
        ('terms', '/legal/terms/', 'terms_title', 'terms_desc'),
        ('support', '/Support/', 'support_title', 'support_desc'),
        ('apps', '/apps/', 'apps_title', 'apps_desc'),
        ('projects', '/projects/', 'projects_title', 'projects_desc'),
    ]
    for lang in ('en', 'de'):
        copy = I18N[lang]
        root = locale_root(lang)
        home = locale_home(lang)
        support_ui = escape(json.dumps({
            'answers_empty': copy['answers_empty'],
            'answers_send': copy['answers_send'],
            'answers_mention': copy['answers_mention'],
        }, ensure_ascii=False, separators=(',', ':')), quote=True)
        values = {
            'latest_cards': latest_cards(lang, root, copy),
            'project_cards': project_cards(lang, root, copy),
            'project_tiles': project_tiles(root),
            'contact_email': escape(SITE['email']),
            'contact_phone': escape(phone_display()),
            'contact_phone_href': escape(phone_href(), quote=True),
            'support_cards': dollar(support_cards(lang)),
            'support_articles': dollar(support_articles_html(articles, copy)),
            'support_feed': escape(SUPPORT_FEED, quote=True),
            'support_apps': escape(json.dumps(
                [{'slug': p['slug'], 'name': p['name']} for p in local_projects()],
                separators=(',', ':'),
            ), quote=True),
            'support_overrides': escape(json.dumps(
                load_support_overrides(),
                ensure_ascii=False,
                separators=(',', ':'),
            ), quote=True),
            'support_ui': dollar(support_ui),
            'root': root, 'home': home,
            'assets': ASSETS,
            'error_home': escape(copy['error_home']),
            'nav_projects': escape(copy['nav_projects']),
        }
        home_html = Template(page_source('home', lang).read_text()).substitute(values)
        page('/', copy['home_title'], copy['home_desc'], home_html, lang, LOGO)
        error_source = page_source('error', lang)
        if error_source.exists():
            page(
                '/error-page.html',
                copy['error_title'] + ' — Gabriel Sgroi',
                copy['error_desc'],
                Template(error_source.read_text()).substitute(values),
                lang,
                LOGO,
            )
        for name, path, title_key, desc_key in routes:
            source = page_source(name, lang)
            if source.exists():
                page(path, copy[title_key] + ' — Gabriel Sgroi', copy[desc_key],
                     Template(source.read_text()).substitute(values), lang)
        for project in local_projects():
            source = page_source(project['slug'], lang)
            if source.exists():
                project_values = dict(values, product_icon=icon(project))
                store_url = project['app_store_url']
                project_values['store_action'] = (
                    f'<a class="button" href="{escape(store_url, quote=True)}" rel="noopener">{escape(copy["store_download"])}</a>'
                    if store_url else
                    f'<a class="button" href="{root}/apps/">{escape(copy["store_available"])} <span aria-hidden="true">↗</span></a>'
                )
                page(
                    '/projects/' + project['slug'] + '/',
                    project['name'] + ' — Gabriel Sgroi',
                    text_for(project, lang, 'description'),
                    Template(source.read_text()).substitute(project_values),
                    lang,
                    project['icon'],
                )
    redirects()
    print('Static pages and legacy redirects built.')


if __name__ == '__main__':
    build()
